import{a6 as t}from"./index-BsVrMvf8.js";function s(a,r){const e=t(a),f=t(r);return+e==+f}export{s as i};

import{P as r}from"./index-BTcyLkMm.js";function t(s,a){return r(s,-a)}export{t as s};

import{a8 as r,r as a}from"./index-BsVrMvf8.js";function o({title:t}){const e=r();return a.useLayoutEffect(()=>(e(t),()=>e("")),[t,e]),null}export{o as P};

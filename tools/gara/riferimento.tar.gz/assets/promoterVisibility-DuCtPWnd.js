const t=s=>!!s&&(s.status==="attivo"||s.show_in_stats!==!1);export{t as i};

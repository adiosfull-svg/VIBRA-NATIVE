import{bN as r,r as s}from"./index-BTcyLkMm.js";function o({title:t}){const e=r();return s.useLayoutEffect(()=>(e(t),()=>e("")),[t,e]),null}export{o as P};

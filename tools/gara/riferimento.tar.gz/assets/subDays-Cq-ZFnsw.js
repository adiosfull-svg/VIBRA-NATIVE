import{a7 as r}from"./index-BsVrMvf8.js";function t(a,s){return r(a,-s)}export{t as s};

import{A as c,az as l,r as n,aB as i,aA as d}from"./index-BsVrMvf8.js";/**
 * @license lucide-react v0.475.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const f=[["path",{d:"M12.83 2.18a2 2 0 0 0-1.66 0L2.6 6.08a1 1 0 0 0 0 1.83l8.58 3.91a2 2 0 0 0 1.66 0l8.58-3.9a1 1 0 0 0 0-1.83z",key:"zw3jo"}],["path",{d:"M2 12a1 1 0 0 0 .58.91l8.6 3.91a2 2 0 0 0 1.65 0l8.58-3.9A1 1 0 0 0 22 12",key:"1wduqc"}],["path",{d:"M2 17a1 1 0 0 0 .58.91l8.6 3.91a2 2 0 0 0 1.65 0l8.58-3.9A1 1 0 0 0 22 17",key:"kqbvx6"}]],p=c("Layers",f);function h(e){const t=l(e),[a,o]=n.useState(null);return n.useEffect(()=>{if(!t)return;let r=!0;const s=i(e);return s.promise.then(u=>{r&&o({src:e,url:u})}),()=>{r=!1,s.release()}},[e,t]),t?(a==null?void 0:a.src)===e?a.url:d(e):e||""}export{p as L,h as u};

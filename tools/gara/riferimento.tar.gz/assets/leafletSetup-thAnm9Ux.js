import{L as o}from"./leaflet-src-CdqbEWcT.js";import"./index-BsVrMvf8.js";window.L=o;export{o as default};

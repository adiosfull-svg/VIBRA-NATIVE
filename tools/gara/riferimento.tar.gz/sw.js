/**
 * Service Worker VIBRA — app-shell precaching + runtime caching API/foto.
 *
 * Strategie:
 * 1. App shell (navigazioni HTML): network-first, fallback cache → offline OK.
 * 2. Asset statici (JS, CSS, font): stale-while-revalidate → instant repeat.
 * 3. API Base44 (chiamate dati): network-first, copia in cache SOLO come riserva offline.
 *    Prima era stale-while-revalidate: React Query riceveva la risposta del fetch
 *    precedente come se fosse fresca (dati sempre "un aggiornamento indietro").
 *    La navigazione istantanea è già garantita dalla cache React Query su IndexedDB.
 * 4. Immagini (foto profilo, loghi locali, CDN): cache-first, scadenza 7 giorni.
 *
 * Niente cache per POST/PUT/DELETE (mutazioni): sempre network.
 */

const CACHE_VERSION = 'vibra-v4';
const SHELL_CACHE = `${CACHE_VERSION}-shell`;
const RUNTIME_CACHE = `${CACHE_VERSION}-runtime`;
const IMG_CACHE = `${CACHE_VERSION}-img`;
// Cache separata e limitata per le risposte API (riserva offline).
const API_CACHE = `${CACHE_VERSION}-api`;
const API_CACHE_MAX = 150;

// Tiene la cache API entro API_CACHE_MAX voci (le più vecchie escono per prime).
function trimApiCache() {
  return caches.open(API_CACHE).then((cache) =>
    cache.keys().then((keys) => {
      const extra = keys.length - API_CACHE_MAX;
      if (extra <= 0) return;
      return Promise.all(keys.slice(0, extra).map((k) => cache.delete(k)));
    })
  ).catch(() => {});
}

const APP_SHELL = [
  '/',
  '/index.html',
];

// Asset statici: JS, CSS, font, wasm
const STATIC_RE = /\.(?:js|css|woff2?|ttf|otf|wasm|svg)$/i;

// API Base44: chiamate al backend ( qualsiasi *.base44.app )
const API_RE = /base44\.app\/(?:api|functions)/i;

// Immagini: foto profilo, loghi, CDN
const IMG_RE = /\.(?:png|jpg|jpeg|gif|webp|avif|ico)$/i;
const CDN_RE = /(?:scontent|cdn|storage|googleusercontent|cloudfront|base44\.app\/storage)/i;

self.addEventListener('install', (event) => {
  event.waitUntil(
    caches.open(SHELL_CACHE).then((cache) => cache.addAll(APP_SHELL)).then(() => self.skipWaiting())
  );
});

self.addEventListener('activate', (event) => {
  event.waitUntil(
    caches.keys().then((keys) =>
      Promise.all(
        keys
          .filter((k) => !k.startsWith(CACHE_VERSION))
          .map((k) => caches.delete(k))
      )
    )
      // Pulizia una tantum: le vecchie risposte API stavano nella cache runtime
      // (senza limite). Le togliamo, lasciando intatti JS/CSS/font.
      .then(() => caches.open(RUNTIME_CACHE).then((cache) =>
        cache.keys().then((keys) => Promise.all(
          keys.filter((k) => API_RE.test(k.url)).map((k) => cache.delete(k))
        ))
      ).catch(() => {}))
      .then(() => self.clients.claim())
  );
});

self.addEventListener('fetch', (event) => {
  const req = event.request;

  // Solo GET: mai cacheare mutazioni
  if (req.method !== 'GET') return;

  const url = new URL(req.url);

  // DEV bypass: mai intercettare risorse del dev server Vite o sorgenti.
  // Un SW residuo da un build PROD precedente non deve cacheare i chunk
  // .vite/deps (React/query) né i moduli /src — altrimenti serve chunk
  // stale che risolvono React a null → "Cannot read properties of null
  // (reading 'useContext')".
  if (
    url.pathname.startsWith('/node_modules/.vite/') ||
    url.pathname.startsWith('/@vite') ||
    url.pathname.startsWith('/@react-refresh') ||
    url.pathname.startsWith('/src/')
  ) {
    return;
  }

  // Navigazioni HTML: network-first, fallback shell
  if (req.mode === 'navigate' || (req.headers.get('accept') || '').includes('text/html')) {
    event.respondWith(
      fetch(req)
        .then((res) => {
          const copy = res.clone();
          caches.open(SHELL_CACHE).then((c) => c.put(req, copy));
          return res;
        })
        .catch(() => caches.match(req).then((r) => r || caches.match('/')))
    );
    return;
  }

  // Immagini: cache-first, scadenza 7 giorni
  if (IMG_RE.test(url.pathname) || CDN_RE.test(url.hostname)) {
    event.respondWith(
      caches.open(IMG_CACHE).then((cache) =>
        cache.match(req).then((cached) => {
          if (cached) {
            // Refresh in background
            fetch(req).then((res) => {
              if (res.ok) cache.put(req, res.clone());
            }).catch(() => {});
            return cached;
          }
          return fetch(req).then((res) => {
            if (res.ok) cache.put(req, res.clone());
            return res;
          }).catch(() => cached);
        })
      )
    );
    return;
  }

  // API Base44: network-first, cache solo come riserva quando la rete non risponde
  if (API_RE.test(url.href)) {
    event.respondWith(
      fetch(req)
        .then((res) => {
          if (res.ok) {
            const copy = res.clone();
            caches.open(API_CACHE)
              .then((cache) => cache.put(req, copy))
              .then(trimApiCache)
              .catch(() => {});
          }
          return res;
        })
        .catch(() =>
          caches.open(API_CACHE)
            .then((cache) => cache.match(req))
            .then((r) => r || Response.error())
        )
    );
    return;
  }

  // Asset statici: stale-while-revalidate
  if (STATIC_RE.test(url.pathname) || url.pathname.startsWith('/assets/')) {
    event.respondWith(
      caches.open(RUNTIME_CACHE).then((cache) =>
        cache.match(req).then((cached) => {
          const networkFetch = fetch(req).then((res) => {
            if (res.ok) cache.put(req, res.clone());
            return res;
          }).catch(() => cached);
          return cached || networkFetch;
        })
      )
    );
    return;
  }

  // Default: prova network, fallback cache
  event.respondWith(
    fetch(req).catch(() => caches.match(req).then((r) => r || Response.error()))
  );
});

// ── Push notifications ──
// Riceve la push dal server e mostra la notifica nativa.
self.addEventListener('push', (event) => {
  let data;
  try {
    data = event.data ? event.data.json() : {};
  } catch {
    data = { title: 'Vibra', body: event.data ? event.data.text() : '' };
  }
  const title = data.title || 'Vibra';
  const options = {
    body: data.body || '',
    icon: 'https://media.base44.com/images/public/69de4f1f7f53d9f187d01392/bb9cb01fc_VIBRAPERFETTO.png',
    badge: 'https://media.base44.com/images/public/69de4f1f7f53d9f187d01392/bb9cb01fc_VIBRAPERFETTO.png',
    tag: data.tag || 'vibra-notification',
    data: { action_url: data.action_url || '/' },
    vibrate: [100, 50, 100],
  };
  event.waitUntil(self.registration.showNotification(title, options));
});

// Click sulla notifica: focusa l'app già aperta e naviga via postMessage (niente full reload).
// Se l'app non è aperta, apre una nuova finestra all'action_url.
self.addEventListener('notificationclick', (event) => {
  event.notification.close();
  const actionUrl = event.notification.data?.action_url || '/';
  event.waitUntil(
    clients.matchAll({ type: 'window', includeUncontrolled: true }).then((clientList) => {
      for (const client of clientList) {
        if (client.url.includes(self.location.origin)) {
          client.focus();
          client.postMessage({ type: 'NAVIGATE', url: actionUrl });
          return;
        }
      }
      if (clients.openWindow) return clients.openWindow(actionUrl);
    })
  );
});
